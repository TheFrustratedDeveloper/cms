<?php
    function escape($string){
        global $connect;
        return mysqli_real_escape_string($connect,$string);
    }
    function create_category(){
        global $connect;
        if(isset($_POST['submit'])){
           $catTitle = $_POST['cat_title'];
           if(empty($catTitle)){
              echo "<div class='alert alert-danger'>
                    <strong>Warning!</strong> Category Field can't be empty.
                    </div>";
              }else{
                    $query = "INSERT INTO category(`cat_title`) VALUES ('$catTitle')";
                    $addQuery = mysqli_query($connect,$query);
                    if(!$addQuery){
                        die();
                    }else{
                        echo "<div class='alert alert-success''>";
                        echo "<strong>Success!</strong> Category Added.";
                        echo "</div>";                                        
                    }
           }
            header( "refresh:2; url=add_cat.php" );
        }
    }   
    function show_category(){
        global $connect;
        $selectAllfromCat = "SELECT * FROM category";
        $showAllfromCat = mysqli_query($connect,$selectAllfromCat); 
        while($row = mysqli_fetch_assoc($showAllfromCat)){
            $catID = $row['cat_id'];
            $catTitle = $row['cat_title'];
            echo "<tr>";
            echo "<td>$catID</td>";
            echo "<td>$catTitle</td>";
            echo "<td><a class='btn btn-danger form-control' href='add_cat.php?delete=$catID&title=$catTitle'>Delete</a></td>";
            echo "<td><a class='btn btn-primary form-control' style='margin-left:5px;' href='add_cat.php?edit=$catID&title=$catTitle'>Edit</a></td>";
            echo "</tr>";
        }
    }
    function update_category(){
        global $connect;
        if(isset($_GET['edit'])){ //to show update textfield with cat_title in it
            $catID_edit = $_GET['edit'];
            $catTitle_edit = $_GET['title']; 
            echo "<div class='form-group'>";
            echo "<label for='cat'>Edit Category Name</label>";
            echo "<input value='$catTitle_edit' class='form-control' type='text' name='cat_update_title'>";
            echo "</div>";
            echo "<div class='form-group'>";
            ?><?php //to update the selected category 
            if(isset($_POST['update'])){
                $updated_title = $_POST['cat_update_title'];
                $catID_edit = $_GET['edit'];
                $query = "UPDATE category SET cat_title = '$updated_title' WHERE cat_id = $catID_edit";
                $editQuery = mysqli_query($connect,$query);
                if(!$editQuery){die();}else{
                    echo "<div class='alert alert-success''>";
                    echo "<strong>Success!</strong> Category Edited.";
                    echo "</div>";
                }
                header( "refresh:2; url=add_cat.php" );
            }
            ?><?php //to show update button
            echo "<input class='btn btn-warning' type='submit' name='update' value='Update'>";
            echo "</div>";
        }
    }
    function delete_category(){
        global $connect;
        if(isset($_GET['delete'])){
            $catID_delete = $_GET['delete'];
            $catTitle_delete = $_GET['title'];
            $deleteQuery = "DELETE FROM category WHERE cat_id = $catID_delete";
            $delete = mysqli_query($connect,$deleteQuery);
            if(!$delete){die();}else{
                echo "  <div class='alert alert-danger'>
                        <strong>Deleted!</strong><br>Category named <b>$catTitle_delete</b> is deleted.
                        </div>";
                }
            header( "refresh:2; url=add_cat.php" );
        }
    }
    function addNewPost(){
        global $connect;
        if(isset($_POST['publish'])){
            $postTitle = $_POST['title'];
            $postAuthor = $_POST['author'];
            $postStatus = $_POST['status'];
            $cat_id = $_POST['category_id'];
            if(empty($cat_id)){
                echo( "<div class='alert alert-danger'>
                <strong>Category Not Selected</strong><br>Please select category before adding the post.</div>
                <div class='alert alert-danger'>Taking you back to previous page ...</div>"
                    );
                header( "refresh:3; url=post_list.php?source=add_post");
                die(mysqli_error($connect));
                }                    
            $postImg = $_FILES['image']['name'];
            $postImgTemp = $_FILES['image']['tmp_name'];
                                
            $postTag = $_POST['tags'];
            $postContent = $_POST['content'];
            $postDate = date('d-m-y');
                            
            move_uploaded_file($postImgTemp,"../images/$postImg");
                                
            $query = "INSERT INTO posts(post_title,cat_id,post_author,post_img,post_content,post_tag,post_status,post_date) VALUES('$postTitle',$cat_id,'$postAuthor','$postImg','$postContent','$postTag','$postStatus',now())";
                            
            $addPost = mysqli_query($connect,$query);
            if(!$addPost){die(mysqli_error($connect));}else{
                echo " <div class='alert alert-success'>
                <strong>Sucessful!</strong><br>Post Added.
                </div>";
                $postID = mysqli_insert_id($connect);
             echo "<div class='alert alert-success'><strong><a href='post_list.php'>View All Posts</a></strong> or <strong><a href='post_list.php?source=edit_post&p_id=$postID'>Edit This Post</a></strong></div>";   
            }                      
        }
    }
    function viewPosts(){
        global $connect;
        $selectAllfromPosts = "SELECT * FROM posts ORDER BY post_id DESC";
        $showAllfromPosts = mysqli_query($connect,$selectAllfromPosts);

        while($row = mysqli_fetch_assoc($showAllfromPosts)){
            $postID = $row['post_id'];
            $catID = $row['cat_id'];
            
            $selectCatTitle = "SELECT cat_title FROM category WHERE cat_id=$catID";
            $showCatTitle = mysqli_query($connect,$selectCatTitle);
            $rowTitle = mysqli_fetch_assoc($showCatTitle);
            $cat_title = $rowTitle['cat_title'];
            
            $postTitle = $row['post_title'];
            $postViews = $row['views_count'];
            $postAuthor = $row['post_author'];
            $postDate = $row['post_date'];
            $postImg = $row['post_img'];
            $postCmtCount = $row['post_cmt_count'];
            $postStatus = $row['post_status'];
            //Print into table                    
            echo "<tr>";
            echo "<td><input type='checkbox' class='checkboxes' name='checkBoxArray[]' value=$postID></td>";
            echo "<td>$postID</td>";
            echo "<td><a href='../post.php?p_id=$postID'>$postTitle</a></td>";
            echo "<td>$postViews</td>";
            echo "<td><a href='post_list.php?reset=$postID' class= 'btn btn-default fa fa-refresh' title='Reset Views' id='reset' data-toggle='popover' data-trigger='hover' data-content='You can reset Views'>&nbsp;&nbsp;Reset</a></td>";
            echo "<td>$postAuthor</td>";
            echo "<td>$cat_title</td>";
            echo "<td>$postDate</td>";
            echo "<td>$postStatus</td>";
            
            $query = "SELECT * FROM comments WHERE cmt_post_id = '$postID' ";
            $cmtCount = mysqli_query($connect,$query);
            $cmtRows = mysqli_num_rows($cmtCount);
            
            echo "<td><a href='comments.php?p_id=$postID'>$cmtRows</a></td>";
            echo "<td><img width='100' src='../images/$postImg' alt='$postImg'></td>";
            echo "<td class='bg-success'><a class='btn btn-success form-control' href='post_list.php?publish=$postID'>Publish</a></td>";
            echo "<td class='bg-danger'><a class='btn btn-warning form-control' href='post_list.php?draft=$postID'>Draft</a></td>";  
            echo "<td class='bg-info'><a class='btn btn-primary form-control' href='post_list.php?source=edit_post&p_id=$postID'>Edit</a></td>";                      
            echo "<td class='bg-danger'><a onClick=\"javascript : return confirm('Are you Sure to Delete This ?'); \" class='btn btn-danger form-control' href='post_list.php?delete=$postID&title=$postTitle'>Delete</a></td>";
            echo "</tr>";
        }
        if(isset($_GET['reset'])){
            $id = $_GET['reset'];
            $query = "UPDATE posts SET views_count = 0 WHERE post_id = $id";
            $resetViews = mysqli_query($connect,$query);
            header("Location:post_list.php");
        }
    }
    function deletePost(){
        global $connect;
        if(isset($_GET['delete'])){
            $delID = $_GET['delete'];
            $delTitle = $_GET['title'];
            $delQuery = "DELETE FROM posts WHERE post_id = $delID";
            $delContent = mysqli_query($connect,$delQuery);
            if(!$delContent){die();}else{
                echo "  <div class='alert alert-danger'>
                <strong>Deleted!</strong><br>Post named <b>$delTitle</b> will be deleted.
                </div>";
            }
            header( "refresh:1; url=post_list.php");
        }
    }
    function publishPost(){
        global $connect;
        if(isset($_GET['publish'])){
            $pID = $_GET['publish'];
            $query = "UPDATE posts SET post_status = 'published' WHERE `post_id` = $pID";
            $publish_post = mysqli_query($connect,$query);
            if(!$publish_post){die();}else{
                echo "<div class='alert alert-success'>
                <strong>Published!</strong>
                </div>";
                header( "refresh:1; url=post_list.php");
            }
        }
    }
    function draftPost(){
        global $connect;
        if(isset($_GET['draft'])){
            $pID = $_GET['draft'];
            $query = "UPDATE posts SET post_status = 'draft' WHERE `post_id` = $pID";
            $publish_post = mysqli_query($connect,$query);
            if(!$publish_post){die();}else{
                echo "<div class='alert alert-warning'>
                <strong>Post UnPublished!</strong>
                </div>";
                header( "refresh:1; url=post_list.php");
            }
        }        
    }
    function editPost(){
        global $connect;
        if(isset($_POST['Edit'])){
        $p_id = $_GET['p_id'];
        $title = $_POST['title'];
        $category = $_POST['category_id'];
            if(empty($category)){
                echo( "<div class='alert alert-danger'>
                <strong>Category Not Selected</strong><br>Please select category before updating the post.</div>
                <div class='alert alert-danger'>Taking you back to previous page ...</div>"
                    );
                header( "refresh:3; url=post_list.php?source=edit_post&p_id=$p_id");
                die();
                }
        $author = $_POST['author'];
        $content = $_POST['content'];
        $tags = $_POST['tags'];
        $status = $_POST['status'];
        $img = $_FILES['image']['name'];
        $tempImg = $_FILES['image']['tmp_name'];
        $date = date('d-m-y');                  
        move_uploaded_file($tempImg,"../images/$img");
        if(empty($img)){
            $imgQuery = "SELECT * FROM posts WHERE post_id = $p_id";
            $selectImg = mysqli_query($connect,$imgQuery);
            while($row = mysqli_fetch_assoc($selectImg)){
                $img = $row['post_img'];
            }
        }
        $query = "UPDATE posts SET post_title='$title',cat_id=$category,post_author='$author',post_content='$content',post_tag='$tags',post_status='$status',post_img='$img',post_date=now() WHERE post_id = $p_id";
        $editQuery = mysqli_query($connect,$query);
        if(!$editQuery){die("Dead".mysqli_error($connect));}else{
            echo " <div class='alert alert-success'>
                <strong>Sucessfull!</strong><br>Post Edited.
                <br>Will be refreshing to HOME within 5 seconds ...
                </div>";
            
            header( "refresh:3; url=post_list.php");
        }
}
}
    function viewComments(){
        global $connect;
        $selectAllfromCmts = "SELECT * FROM comments";
        $showAllfromCmts = mysqli_query($connect,$selectAllfromCmts);

        while($row = mysqli_fetch_assoc($showAllfromCmts)){
            $cmtID = $row['cmt_id'];
            $cmtAuthor = $row['cmt_author'];
            $cmtEmail = substr($row['cmt_email'],0,11);
            $cmtContent = substr($row['cmt_content'],0,21);
            //Start of in Response to
            $selectfromcomment = "SELECT cmt_post_id FROM comments WHERE cmt_id=$cmtID";
            $showCommentP_ID = mysqli_query($connect,$selectfromcomment);
            $rowPID = mysqli_fetch_assoc($showCommentP_ID);
            $pID = $rowPID['cmt_post_id'];
            //\\//\\//\\//\\//\\//\\//\\//\\
            $selectfromPost = "SELECT post_title FROM posts WHERE post_id=$pID";
            $showPostTitle = mysqli_query($connect,$selectfromPost);
            $rowR_TO = mysqli_fetch_assoc($showPostTitle);
            $responseTo = $rowR_TO['post_title'];
            //End of in Response to    
            $cmtStatus = $row['cmt_status'];
            $cmtDate = $row['cmt_date'];
            //Print into table                    
            echo "<tr>";
            echo "<td><input type='checkbox' class='checkboxes' name='checkBoxArray[]' value=$cmtID></td>";
            echo "<td>$cmtID</td>";
            echo "<td>$cmtAuthor</td>";
            echo "<td>$cmtEmail...</td>";
            echo "<td>$cmtContent...</td>";
            echo "<td><a href='../post.php?p_id=$pID'>$responseTo</a></td>";
            echo "<td>$cmtStatus</td>";
            echo "<td>$cmtDate</td>";
            echo "<td><a class='btn btn-info' href='cmt_list.php?approve=$cmtID'>Approve</a></td>";
            echo "<td><a class='btn btn-warning ' style='margin-left:5px;' href='cmt_list.php?disapprove=$cmtID'>Dis-Approve</a></td>";
            echo "<td><a class='btn btn-danger' style='margin-left:5px;' href='cmt_list.php?delete=$cmtID'>Delete</a></td>";
            echo "</tr>";
        }
    }
    function deleteComment(){
        global $connect ;
        if(isset($_GET['delete'])){
            $delID = escape($_GET['delete']);
            $query = "DELETE FROM comments WHERE cmt_id = $delID";
            $delQuery = mysqli_query($connect,$query);
            if(!$delQuery){die();}else{
                echo "<div class='alert alert-danger'>
                <strong>Comment Deleted!</strong>
                </div>";
                header( "refresh:1; url=cmt_list.php");
            }
        }
    }
    function approveComment(){
        global $connect ;
        if(isset($_GET['approve'])){
            $apvID = $_GET['approve'];
            $query = "UPDATE comments SET cmt_status = 'approved' WHERE cmt_id = $apvID";
            $apvQuery = mysqli_query($connect,$query);
            if(!$apvQuery){die();}else{
                echo "<div class='alert alert-success'>
                <strong>Comment Approved</strong>
                </div>";
                header( "refresh:1; url=cmt_list.php");
            }
        }
    }
    function disApproveComment(){
        global $connect ;
        if(isset($_GET['disapprove'])){
            $diapvID = $_GET['disapprove'];
            $query = "UPDATE comments SET cmt_status = 'dis-approved' WHERE cmt_id = $diapvID";
            $disapvQuery = mysqli_query($connect,$query);
            if(!$disapvQuery){die();}else{
                echo "<div class='alert alert-warning'>
                <strong>Comment DIS-Approved</strong>
                </div>";
                header( "refresh:1; url=cmt_list.php");
            }
        }
    }
    function viewUsers(){
        global $connect;
        $selectAllfromUsers = "SELECT * FROM users";
        $showAllfromusers = mysqli_query($connect,$selectAllfromUsers);
        while($row = mysqli_fetch_assoc($showAllfromusers)){
            $usrID = $row['user_id'];
            $username = $row['username'];
            $profilePic = $row['user_image'];
            $fName = $row['first_name'];
            $lName = $row['last_name'];
            $email = substr($row['email'],0,11);
            $forRole = $row['for_role'];
            $role = $row['role'];
            //Print into table                    
            echo "<tr>";
            echo "<td>$usrID</td>";
            echo "<td>$username</td>";
            echo "<td><img width='30' height='30' src='../images/users/$profilePic' alt='$profilePic'></td>";
            echo "<td>$fName</td>";
            echo "<td>$lName</td>";
            echo "<td>$email...</td>";
            echo "<td>$role</td>";
            $query = "SELECT * FROM role WHERE role_id = $forRole";
            $showRole = mysqli_query($connect,$query);
            $role = mysqli_fetch_array($showRole);
            $roleTitle = $role['role_title'];
            echo "<td>$roleTitle</td>";
            echo "<td class='bg-info'><a class='btn btn-primary' href='users_list.php?adminApprove=$usrID&username=$username'>Admin</a></td>";
            echo "<td class='bg-success'><a class='btn btn-success' href='users_list.php?subscriber=$usrID&username=$username'>Subscriber</a></td>";
            echo "<td class='bg-warning'><a class='btn btn-warning' href='users_list.php?block=$usrID'>Block</a></td>";
            echo "<td class='bg-info'><a class='btn btn-info' href='users_list.php?source=editUser&id=$usrID'>Edit</a></td>";
            echo "<td class='bg-danger'><a onClick=\"javascript : return confirm('Are you Sure to Delete This ?'); \" class='btn btn-danger' href='users_list.php?delete=$usrID'>Delete</a></td>";
            echo "</tr>";
        }
    }
    function addUser(){
        global $connect;
        if(isset($_POST['addUser'])){
            $firstname = $_POST['fname'];
            $lastname = $_POST['lname'];
            $email = $_POST['email'];
            $for_role = $_POST['for_role'];                   
            $userImg = $_FILES['image']['name'];
            $userImgTemp = $_FILES['image']['tmp_name'];
            $username = $_POST['username'];
            
            $duplicateUsername = "SELECT * FROM users WHERE username = '$username'";
            $doQuery = mysqli_query($connect,$duplicateUsername);
            $dubUser = mysqli_fetch_assoc($doQuery);
            $duplicateUser = $dubUser['username'];
            if($duplicateUser == $username){
                echo   "<div class='alert alert-warning'>
                <strong>Please Select Different Username !</strong>
                <small>Duplication Found.</small>
                </div>";
                header( "refresh:2; url=users_list.php?source=add_user");
                die();
            }
            
            $password = $_POST['password'];
            $confirmPassword = $_POST['cnfrmPassword'];
            
            if($password === $confirmPassword){
                $password = password_hash("$password",PASSWORD_BCRYPT,array('cost' => 12));
                $dateAdded = date('d-m-y');             
                move_uploaded_file($userImgTemp,"../images/users/$userImg");                    
                $query = "INSERT INTO users(first_name,last_name,email,for_role,user_image,username,password,dateAdded) VALUES('$firstname','$lastname','$email',$for_role,'$userImg','$username','$password',now())";         
                $addUser = mysqli_query($connect,$query);
                if(!$addUser){die();}else{
                    echo "<div class='alert alert-success'>
                          <strong>Registered Sucessfully!</strong><br>Please wait till we verify.
                          </div>";
                    header( "refresh:3; url=includes/viewAllUsers.php");
                }
            }else {
            echo   "<div class='alert alert-warning'>
                <strong>Password Incorrect !</strong>
                <small>Both Passwords should be same.</small>
                </div>";
                header( "refresh:1; url=users_list.php?source=add_user");
                die();
            }
        }
    }
    function deleteUser(){
        global $connect ;
        if(isset($_GET['delete'])){
            if(isset($_SESSION['role'])){
                if($_SESSION['role'] == 'Admin'){
                    $delID = mysqli_real_escape_string($connect,$_GET['delete']);
                    $query = "DELETE FROM users WHERE user_id = $delID";
                    $delQuery = mysqli_query($connect,$query);
                    if(!$delQuery){die();}else{
                        echo "<div class='alert alert-danger'>
                        <strong>User Deleted!</strong>
                        </div>";
                        header( "refresh:1; url=users_list.php");
                    }  
                }
            } 
        }
    }
    function makeAdmin(){
        global $connect;
        if(isset($_GET['adminApprove'])){
            $userID = $_GET['adminApprove'];
            $username = $_GET['username'];
            $query = "UPDATE users SET role = 'Admin' WHERE user_id = $userID";
            $makeAdmin = mysqli_query($connect,$query);
            if(!$makeAdmin){die();}else{
                echo "<div class='alert alert-success'>
                <strong>$username has been promoted to Admin</strong>
                </div>";
                header( "refresh:1; url=users_list.php");
            }
        }
    }
    function makeSubscriber(){
        global $connect;
        if(isset($_GET['subscriber'])){
            $userID = $_GET['subscriber'];
            $username = $_GET['username'];
            $query = "UPDATE users SET role = 'Subscriber' WHERE user_id = $userID";
            $makeSubscriber = mysqli_query($connect,$query);
            if(!$makeSubscriber){die();}else{header( "Location:users_list.php");}
        }
    }
    function blockThatUser(){
        global $connect;
        if(isset($_GET['block'])){
            $userID = $_GET['block'];
            $query = "UPDATE users SET role = 'Blocked' WHERE user_id = $userID";
            $blocked = mysqli_query($connect,$query);
            if(!$blocked){die();}else{header("Location:users_list.php");}
        }
    } 
    function editUser(){
        global $connect;
        
        if(isset($_POST['editUser'])){
            
            $id = $_GET['id'];
            $firstname = $_POST['fname'];
            $lastname = $_POST['lname'];                   
            $userImg = $_FILES['image']['name'];
            $userImgTemp = $_FILES['image']['tmp_name'];
            $username = $_POST['username'];
            $oldPassword = $_POST['oldPassword'];
                
            $selectOLDPassword = "SELECT * FROM users WHERE user_id = $id";
            $showOLDPassword = mysqli_query($connect,$selectOLDPassword);
            $row = mysqli_fetch_assoc($showOLDPassword);
            $oldPswrd = $row['password'];
            
            if(password_verify("$oldPassword","$oldPswrd")){
                $password = $_POST['password'];
                $confirmPassword = $_POST['cnfrmPassword'];
                if($password !== $confirmPassword){
                    echo   "<div class='alert alert-warning'>
                            <strong>Password Incorrect !</strong>
                            <small>Both Passwords should be same.</small>
                            </div>";
                    header( "refresh:1; url=users_list.php?source=editUser&id=$id");
                    die();
                }else{
                    $password = password_hash("$password",PASSWORD_BCRYPT,array('cost' => 12));
                    $dateAdded = date('d-m-y');            
                    move_uploaded_file($userImgTemp,"../images/users/$userImg");
                    if(empty($userImg)){
                        $imgQuery = "SELECT * FROM users WHERE user_id = $id";
                        $selectImg = mysqli_query($connect,$imgQuery);
                        while($row = mysqli_fetch_assoc($selectImg)){
                            $userImg = $row['user_image'];
                        }
                    }
                    $query = "UPDATE users SET first_name='$firstname', last_name='$lastname', user_image='$userImg', username='$username' , password='$password' , dateAdded = now() WHERE user_id = $id";
                    $addUser = mysqli_query($connect,$query);
                    if(!$addUser){die();}else{
                        echo "  <div class='alert alert-success'>
                                <strong>Updated Sucessfully!</strong>
                                </div>  ";
                        header( "refresh:3; url=index.php");   
                    }
                }
            }  //checking password ends         
        }
         //mainIF statement ends   
    } //function ends

    function onlineUserCount(){
        if(isset($_GET['chkOnline'])){    
        include "../../includes/db_connect.php";   
        session_start();
        $session = session_id();
        $time = time();
        $timeOutInSec = 60;
        $timeOut = $time - $timeOutInSec;
        
        $timeQuery = "SELECT * FROM online WHERE session = '$session' ";
        $sendTimeQuery = mysqli_query($connect,$timeQuery);
        $onlineCount = mysqli_num_rows($sendTimeQuery);
        if($onlineCount == null){
            mysqli_query($connect,"INSERT INTO online(session,time) VALUES('$session','$time')"); 
        }else{
            mysqli_query($connect,"UPDATE online SET time = '$time' WHERE session = '$session'");
        }
        $usersOnline = mysqli_query($connect,"SELECT * FROM online WHERE time > '$timeOut'");
        echo $countUser = mysqli_num_rows($usersOnline);
        }
    }
    onlineUserCount();
    


?>

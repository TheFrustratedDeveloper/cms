<?php 
    Class config{
    //    const SMTP_HOST = 'smtp.mailtrap.io';
       const SMTP_HOST = 'smtp.gmail.com';
    //    const SMTP_PORT = 2525;
        const SMTP_PORT = 587 ;
    //    const SMTP_USER = '2392f7ca0c46a9';
       const SMTP_USER = 'dhruvsaaaxena.1998@gmail.com';
    //    const SMTP_PASSWORD = '2e42f2170c6252';
       const SMTP_PASSWORD = 'Tsg-msn191274';
    }
?>
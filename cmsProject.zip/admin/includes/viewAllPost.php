
   <form action="" method="post">                        
    <table class="table table-bordered table-hover">

        <thead>
            <tr>
               <th><input type="checkbox" name="" id="selectAllBoxes"></th>
               <th>ID</th>
                <th>Title</th>
                <th colspan="2">Views</th>
                <th>Author</th>
                <th>Category</th>
                <th>Date</th>
                <th>Status</th>
                <th>Cmts</th>
                <th>Cover</th>
                <th colspan ="2">Publish or Draft </th>
                <th colspan ="2">Options</th>
            </tr>
        </thead>
    <?php 
    //view all post 
    viewPosts();
    //delete post
    deletePost();
    //edit post
    publishPost();
    //publish post
    draftPost();
    ?>
     <div id="bulkSelector" class="col-xs-4"  style="padding: 0px;margin-right:5px;">
            <?php
                    if(isset($_POST['checkBoxArray'])){
                        foreach($_POST['checkBoxArray'] as $checkBoxValue){
                            $bulkOption = $_POST['bulkOption'];
                            
                            switch($bulkOption){
                                case 'published':
                                    $query = "UPDATE posts SET post_status = '$bulkOption' WHERE post_id = $checkBoxValue";
                                    $publishPosts = mysqli_query($connect,$query);
                                    if(!$publishPosts){die();}else{header("Location:post_list.php");}
                                break;
                                    
                                case 'draft':
                                    $query = "UPDATE posts SET post_status = '$bulkOption' WHERE post_id = $checkBoxValue";
                                    $draftPosts = mysqli_query($connect,$query);
                                    if(!$draftPosts){die();}else{header("Location:post_list.php");}
                                break;
                                    
                                case 'delete':
                                    $query = "DELETE FROM posts WHERE post_id = $checkBoxValue";
                                    $deletePosts = mysqli_query($connect,$query);
                                    if(!$deletePosts){die();}else{header("Location:post_list.php");}
                                break;
                                    
                                case 'clone':
                                    $query = "SELECT * FROM posts WHERE post_id = $checkBoxValue";
                                    $selectQuery = mysqli_query($connect,$query);
                                    while($row = mysqli_fetch_assoc($selectQuery)){
                                        $cat_id = $row['cat_id'];
                                        $post_title = $row['post_title'];
                                        $post_author = $row['post_author'];
                                        $post_img = $row['post_img'];
                                        $post_content = $row['post_content'];
                                        $post_tag = $row['post_tag'];
                                    }
                                    $cloneQuery = "INSERT INTO posts(post_title,cat_id,post_author,post_img,post_content,post_tag,post_date) VALUES('$post_title',$cat_id,'$post_author','$post_img','$post_content','$post_tag',now())";
                                    $doCloneQuery = mysqli_query($connect,$cloneQuery);
                                    if(!$doCloneQuery){die();}else{header("Location:post_list.php");}
                                break;
                                    
                                default : 
                                    echo "<div class='alert alert-danger'>
                                          <strong>Please Select Atleast One Option</strong>
                                          </div>";
                                header( "refresh:1; url=post_list.php");
                            }
                        }
                    }
                ?>
           <select class="form-control form-group" name="bulkOption">
               <option value="refresh" hidden selected>Select One Option</option>    
               <option value="published">Publish</option>
               <option value="draft">Draft</option>
               <option value="delete">Delete</option>
               <option disabled><hr></option>
               <option value="clone">Clone</option>
           </select>
       </div>
       <div class="col-cs-4">
           <input type="submit" class="btn btn-success" value="Apply">
           <a href="post_list.php?source=add_post" class="btn btn-primary">Add New</a>
       </div>
    </table>
</form>
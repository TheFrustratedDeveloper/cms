    <div class="form-group">
    <label for="Password">Password</label>
    <input type="password" name="password" class="form-control" required>
    <label for="pswrd">Password</label>
    <input type="password" name="password" class="form-control" required>
    <label for="confirmPswrd">Confirm Password</label>
    <input type="password" name="cnfrmPassword" class="form-control" required>
    </div>
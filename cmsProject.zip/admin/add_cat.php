<?php include "includes/header.php" ?>
    <div id="wrapper">
        <!-- Navigation -->
        <?php include "includes/nav.php" ?>
        <div id="page-wrapper">
            <div class="container-fluid">
                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Add Category
                            <small>Author_Name</small>
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="index.html"> Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-file"></i> <a href="add_cat.php"> Add Category</a>
                            </li>
                        </ol>
                    </div>
                </div>
                <div class="col-sm-6">
                    <form action="" method="post">
                        <div class="form-group">
                            <label for="cat">Category Name</label>
                            <input class="form-control" type="text" name="cat_title">
                        </div>
                        <div class="form-group">
                            <?php create_category(); ?><!-- to create category -->
                            <input class="btn btn-primary" type="submit" name="submit" value="Submit"><br><br><br>
                            <?php update_category(); ?><!-- to show the selected category in textfield and update it -->
                        </div>
                    </form>
                </div>
                <!-- /.row -->
                <!-- /.table -->
                <div class="col-sm-6">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <td><b>Cat_id</b></td>
                            <td><b>Cat_title</b></td>
                            <td colspan="2"><b>Options</b></td>
                        </tr>
                    </thead>
                    <tbody>
                       <?php //to delete the selected category direct from table
                            delete_category();
                            //to show category in table with options
                            show_category();
                        ?>
                    </tbody>
                </table>
                </div>
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
<?php include "includes/footer.php"; ?>

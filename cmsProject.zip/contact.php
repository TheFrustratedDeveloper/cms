<?php  include "includes/db_connect.php"; ?>
 <?php  include "includes/header.php"; ?>
 <script>
    window.setTimeout(function() {
    $(".alert").fadeTo(500, 0).slideUp(500, function(){
        $(this).remove(); 
    });
}, 4000);    
</script>

<?php 
if(isset($_POST['addUser'])){
    $username = mysqli_real_escape_string($connect,$_POST['username']);
    $email = mysqli_real_escape_string($connect,$_POST['email']);
    $password = mysqli_real_escape_string($connect,$_POST['password']);
    $confirmPassword = mysqli_real_escape_string($connect,$_POST['cnfrmPassword']);
    $fname = mysqli_real_escape_string($connect,$_POST['fname']);
    $lname = mysqli_real_escape_string($connect,$_POST['lname']);
    $for_role = $_POST['for_role'];
    $userImg = $_FILES['image']['name'];
    $userImgTemp = $_FILES['image']['tmp_name'];
    move_uploaded_file($userImgTemp,"images/users/$userImg");  
    
    if(!empty($username) && !empty($password) && !empty($confirmPassword) && !empty($email) && !empty($fname) && !empty($lname)){
            $message = "";
        
            $duplicateUsername = "SELECT * FROM users WHERE username = '$username'";
            $doQuery = mysqli_query($connect,$duplicateUsername);
            $dubUser = mysqli_fetch_assoc($doQuery);
            $duplicateUser = $dubUser['username'];
            if($duplicateUser == $username){
                echo   "<div class='alert alert-warning'>
                        <strong>Please Select Different Username !</strong>
                        <small>Duplication Found.</small>
                        </div>";
                die();
        } 
        if($password === $confirmPassword){
            $password = password_hash("$password",PASSWORD_BCRYPT,array('cost' => 12));
            $registerUser = "INSERT INTO users (username,password,first_name,last_name,email,for_role,user_image,dateAdded) VALUES ('$username','$password','$fname','$lname','$email',$for_role,'$userImg',now())";
            $registerQuery = mysqli_query($connect,$registerUser);
            if(!$registerQuery){die(mysqli_error($connect));}else{
                echo "<script>alert('User Registered! Please wait while we verify the account')</script>";
            }      
        }else{
            echo "<div class='alert alert-warning'>
                <strong>Password Incorrect !</strong>
                <small>Both Passwords should be same.</small>
                </div>";
            header("refresh:3;url=registration.php");
                die(mysqli_error($connect));
        }
        
        
        
    }else{
        $message = "<div class='alert alert-danger'><strong>Input Fields Cannot Be Empty</strong></div>";
    } 
}else{
    $message = "";
}
?>
    <!-- Navigation -->
    
    <?php  include "includes/nav.php"; ?>
    
 
    <!-- Page Content -->
    <div class="container">
<section id="login">
    <div class="container">
        <div class="row">
            <div class="col-xs-6 col-xs-offset-3">
                <div class="form-wrap">
                <h1>Register</h1>
                     <form action="contact.php" method="post" enctype="multipart/form-data">
                           <?php echo $message; ?>
                                <div class="form-group">
                                    <label for="fname">Name</label>
                                    <input type="text" class="form-control" required name="name">
                                </div>
                                <div class="form-group">
                                    <label for="author">E-Mail</label>
                                    <input type="email" class="form-control" required name="email">
                                </div>
                                <div class="form-group">
                                    <label for="subject">Subject</label>
                                    <input type="text" class="form-control" required name="subject">
                                </div>
                                <div class="form-group">
                                    <label for="message">Message</label>
                                    <textarea name="message" id="" cols="30" rows="8" class="form-control"></textarea>
                                </div>
                                <div class="form-group">
                                    <input type="submit" value="Submit" name="sendMessage" class="btn btn-lg btn-success">
                                </div>
                    </form>
                </div>
            </div> <!-- /.col-xs-12 -->
        </div> <!-- /.row -->
    </div> <!-- /.container -->
</section>
        <hr>

<?php include "includes/footer.php";?>

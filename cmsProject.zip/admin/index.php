<?php include "includes/header.php" ?>
    <div id="wrapper">
       <?php 
            
        ?>
        <!-- Navigation -->
        <?php include "includes/nav.php" ?>
        <div id="page-wrapper">
            <div class="container-fluid">
                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Welcome To Admin Panel
                            <small><?php echo $_SESSION['username']; ?></small>
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="index.html">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-file"></i> Blank Page
                            </li>
                        </ol>     
                <!-- /.row -->
  
<div class="row">
    <!--   POSTS  -->
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-file-text fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
<?php 
$query = "SELECT * FROM posts";
$select_allPost = mysqli_query($connect,$query);
$postCount = mysqli_num_rows($select_allPost);
echo "<div class='huge'>$postCount</div>";
?> 
                        <div>Posts</div>
                    </div>
                </div>
            </div>
            <a href="post_list.php">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <!--    COMMENTS  -->
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-green">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-comments fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
<?php 
$query = "SELECT * FROM comments";
$select_allCmts = mysqli_query($connect,$query);
$cmtCount = mysqli_num_rows($select_allCmts);
echo "<div class='huge'>$cmtCount</div>";
?> 
                      <div>Comments</div>
                    </div>
                </div>
            </div>
            <a href="cmt_list.php">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <!--    CATEGORIES  -->
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-red">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-list fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
 <?php 
$query = "SELECT * FROM category";
$select_allcat = mysqli_query($connect,$query);
$catCount = mysqli_num_rows($select_allcat);
echo "<div class='huge'>$catCount</div>";
?> 
                         <div>Categories</div>
                    </div>
                </div>
            </div>
            <a href="add_cat.php">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div> 
    <!--    USERS  -->
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-yellow">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-user fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">
<?php 
$query = "SELECT * FROM users";
$select_allUser = mysqli_query($connect,$query);
$usrCount = mysqli_num_rows($select_allUser);
echo "<div class='huge'>$usrCount</div>";
?> 
                        <div> Users</div>
                    </div>
                </div>
            </div>
            <a href="users_list.php">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>

</div>
                <!-- /.row -->
                
<?php
                        
$query = "SELECT * FROM posts WHERE post_status = 'published'";
$selectAllFromPublished = mysqli_query($connect,$query);
$postPublishedCount = mysqli_num_rows($selectAllFromPublished);
                        
$query = "SELECT * FROM posts WHERE post_status = 'draft'";
$selectAllFromDraft = mysqli_query($connect,$query);
$postDraftCount = mysqli_num_rows($selectAllFromDraft);
                        
$query = "SELECT * FROM comments WHERE cmt_status = 'dis-approved'";
$selectAllFromCmt = mysqli_query($connect,$query);
$postCmtCount = mysqli_num_rows($selectAllFromCmt);
                        
$query = "SELECT * FROM users WHERE role = 'Subscriber'";
$selectAllSubsUsr = mysqli_query($connect,$query);
$postSubCount = mysqli_num_rows($selectAllSubsUsr);

$query = "SELECT * FROM users WHERE role = 'draft'";
$selectAllDraftUsr = mysqli_query($connect,$query);
$postPenCount = mysqli_num_rows($selectAllDraftUsr);                        
?>
            <div class="row">
            <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
        ['Data', 'Count'],
        <?php 
            $elements = ['Total Posts','Active Posts','Draft Posts','Total Comments','Pending Comments','Categories','Users','Subscribers','Pending Users'];
            $elementsCount = [$postCount,$postPublishedCount,$postDraftCount,$cmtCount,$postCmtCount,$catCount,$usrCount,$postSubCount,$postPenCount];
            for($count = 0;$count<9;$count++){
               echo "['{$elements[$count]}',$elementsCount[$count]],";
            }
        ?>
        ]);

        var options = {
          chart: {
            title: 'Webpage Statics',
            subtitle: 'Counts',
          }
        };

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>
    
    <div class="container-fluid" id="columnchart_material" style="width:'auto'; height:300px;"></div>
            </div> 
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
<?php include "includes/footer.php" ?>
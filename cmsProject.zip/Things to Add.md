
12:53 PM 10/16/2017 Correct Pages names in ADMIN section
06:01 PM 10/17/2017 Add Authors in add posts
07:34 PM 10/22/2017 REAL escape changes needed and mysqli injection protections
07:39 PM 10/22/2017 Need to fix delete things without permisssion 
08:30 PM 10/22/2017 Add contact panel into homepage sidebar
<table class="table table-bordered table-hover text-center">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>UserName</th>
                                    <th>Profile</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Email</th>
                                    <th>IS</th>
                                    <th>FOR</th>
                                    <th colspan="3">Options</th>
                                    <th>Edit</th>
                                    <th>Delete</th>
                                    
                                </tr>
                            </thead>
                            <?php 
                                //view all post 
                                viewUsers();
                                //delete comment
                                deleteUser();
                                //Admin Approve
                                makeAdmin();
                                //Subscriber Approved
                                makeSubscriber();
                                //blocking user
                                blockThatUser();
                            ?>
                        </table>
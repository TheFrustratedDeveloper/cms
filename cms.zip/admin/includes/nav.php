        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">   
            <?php include "topNav.php"; ?>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <?php include "sideNav.php"; ?>
            <!-- /.navbar-collapse -->
        </nav>
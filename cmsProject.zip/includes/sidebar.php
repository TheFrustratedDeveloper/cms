<div class="col-md-4">

                <!-- Blog Search Well -->
                <div class="well">
                    <h4>Blog Search</h4>
                    <form action="search.php" method="post">
                    <div class="input-group">
                        <input name="search" type="text" class="form-control">
                        <span class="input-group-btn">
                            <button name="submit" class="btn btn-default" value="OK" type="submit">
                                <span class="glyphicon glyphicon-search"></span>
                        </button>
                        </span>
                    </div>
                    </form>
                    <!-- /.input-group -->
                </div>

                <div class="well">
                    <h4>Login</h4>
                    <form action="includes/login.php" method="post">
                    <div class="form-group">
                        <input name="username" type="text" class="form-control" placeholder="Username">
                    </div>
                    <div class="input-group">
                        <input type="password" name="password" class="form-control" placeholder="Password">
                    
                        <span class="input-group-btn">
                            <button name="login" class="btn btn-primary" value="Login" type="submit">
                                Login
                            </button>
                        </span>
                    </div>
                    <br>
                    <a href="registration.php">Register Here</a>
                    </form>
                    <!-- /.input-group -->
                </div>


                <!-- Blog Categories Well -->
                <div class="well">
                    <h4>Blog Categories</h4>
                    <div class="row">
                        <div class="col-lg-6">
                            <ul class="list-unstyled">
                            <?php
                            $selectAllfromCat = "SELECT * FROM category LIMIT 4";
                            //LIMIT TILL 4TH POST
                            $showAllfromCat = mysqli_query($connect,$selectAllfromCat); 
                            while($row = mysqli_fetch_assoc($showAllfromCat)){
                                $navID = $row['cat_id'];
                                $navTitle = $row['cat_title'];
                                echo "<li><a href='sidebarCategory.php?s_id=$navID'>$navTitle</a></li>";
                            }
                            ?>
                            </ul>
                        </div>
                        <!-- /.col-lg-6 -->
                        <div class="col-lg-6">
                            <ul class="list-unstyled">
                            <?php
                            $selectAllfromCat = "SELECT * FROM category LIMIT 4,8";
                            //LIMIT FROM 4TH POST TO 8TH POST
                            $showAllfromCat = mysqli_query($connect,$selectAllfromCat); 
                            while($row = mysqli_fetch_assoc($showAllfromCat)){
                                $navID = $row['cat_id'];
                                $navTitle = $row['cat_title'];
                                echo "<li><a href='sidebarCategory.php?s_id=$navID'>$navTitle</a></li>";
                            }
                            ?>
                            </ul>
                        </div>
                        <!-- /.col-lg-6 -->
                    </div>
                    <!-- /.row -->
                </div>

                <!-- Side Widget Well -->
                <?php include "widgets.php"; ?>
            </div>
<?php 
    include "db_connect.php";
    session_start();
?>
<?php

    if(isset($_POST['login'])){
        $username =mysqli_real_escape_string($connect,$_POST['username']);
        $password =mysqli_real_escape_string($connect,$_POST['password']);
        
        $query = "SELECT * FROM users WHERE username = '$username'";
        $loginUser = mysqli_query($connect,$query);
        while($row = mysqli_fetch_assoc($loginUser)){
           $login_username = $row['username'];
           $login_password = $row['password'];
            
           $login_id = $row['user_id'];
           $login_fname = $row['first_name'];
           $login_lname = $row['last_name'];
           $login_role = $row['role'];
        }
        global $login_username;
        global $login_password;
        if(password_verify("$password","$login_password")){
            $_SESSION['username'] = $login_username;
            $_SESSION['first_name'] = $login_fname;
            $_SESSION['last_name'] = $login_lname;
            $_SESSION['role'] = $login_role;
            $_SESSION['user_id'] = $login_id;
            if($login_role == 'Admin'){
                header("Location: ../admin");
            }else if($login_role == 'Subscriber'){
                echo "<script>alert('You are registered as Subscriber. Thanks for showing intrest in US')</script>";
                $_SESSION['username'] = null;
                $_SESSION['first_name'] =  null;
                $_SESSION['last_name'] =  null;
                $_SESSION['role'] =  null;
                $_SESSION['user_id'] =  null;
                header("refresh:0.1;url=../index.php");
            }
            else{
                echo "<script>alert('Your account has not been verified. Please Wait while we verify')</script>";
                $_SESSION['username'] = null;
                $_SESSION['first_name'] =  null;
                $_SESSION['last_name'] =  null;
                $_SESSION['role'] =  null;
                $_SESSION['user_id'] =  null;
                header("refresh:0.1;url=../index.php");
            }
        }
        else {  
                if($username == $login_username){
                    echo "<script>alert('Password Incorrect! Please check your password')</script>";
                }else{
                    echo "<script>alert('Username not found')</script>"; 
                }
                header("refresh:0.1;url=../index.php");
        }
    }
?>